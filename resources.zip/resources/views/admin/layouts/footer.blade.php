<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; {{ date('Y') }} <div class="bullet"></div> Design By <a target="_blank" href="https://elscript.com">Elscript</a>
    </div>
    <div class="footer-right">

    </div>
</footer>
